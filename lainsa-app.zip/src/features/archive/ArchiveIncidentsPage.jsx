// ArchiveIncidentsPage.jsx
import React from 'react';
import IncidentsListPage from '../incidents/IncidentsListPage';

export default function ArchiveIncidentsPage() {
  return <IncidentsListPage readOnly />;
}
