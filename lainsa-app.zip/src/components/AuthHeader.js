import React from 'react';

export default function AuthHeader() {
return (
<div style={{
display: 'flex', alignItems: 'center',
borderBottom: '1px solid #eee', padding: '10px 12px'
}}>
<img src="/lainsa-logo.png" alt="LAINSA" style={{ height: 36 }} />
</div>
);
}