export { default } from '../../features/incidents/IncidentForm';
